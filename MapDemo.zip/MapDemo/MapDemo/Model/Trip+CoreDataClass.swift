//
//  Trip+CoreDataClass.swift
//  MapDemo
//
//  Created by Milan on 08/10/22.
//
//

import Foundation
import CoreData


public class Trip: NSManagedObject {

}
